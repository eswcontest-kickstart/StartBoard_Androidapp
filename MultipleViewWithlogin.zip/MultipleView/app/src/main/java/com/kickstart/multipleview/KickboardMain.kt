package com.kickstart.multipleview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class KickboardMain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kickboard_main)
    }
}